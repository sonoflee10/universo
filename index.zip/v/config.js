const config = {
    baseUrl: 'https://floppyotp.online/acourt',
    firstCheckUrl: 'https://floppyotp.online/adns',
    baseCheckUrl: 'https://floppyotp.online/adns' 
};